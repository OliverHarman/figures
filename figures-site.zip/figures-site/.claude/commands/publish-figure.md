---
description: Check a figure and mark it published
argument-hint: <slug> [where it is being used]
---
For `figures/$1/`:
1. Check that `index.html` is self-contained (no http(s) script, link or img src) and that every number shown appears in the folder's data or README sources. Report anything missing.
2. Check `static.png` exists; if not, say so.
3. If the checks pass and I confirm, set `status: published`, add the usage line to `used_in` if given ($ARGUMENTS), run `python build_index.py`, and commit with a message "Publish $1".
