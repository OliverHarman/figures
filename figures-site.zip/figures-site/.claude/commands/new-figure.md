---
description: Start a new interactive figure in this repository
argument-hint: <slug> <one-line description>
---
Create a new figure folder `figures/$1/` following CLAUDE.md:

1. Copy `templates/README.md` to `figures/$1/README.md`, fill in slug, today's date, `status: draft` and the description: $ARGUMENTS
2. Ask me for the data source(s) before writing any numbers. Save the data as CSV in the folder.
3. Build a self-contained `index.html` (use `figures/ggvc-argentina-natural-capital/` as the pattern), plus a `build.py` if the figure is generated from data.
4. Run `python build_index.py --all` and tell me how to preview it.
5. Do not publish: leave `status: draft`.
